import { useCallback, useEffect, useState } from "react";
import { apiGet } from "../api.js";

/**
 * Generic GET with loading / error / empty / success states and a reload().
 * `pick` extracts the array from the payload (e.g. (d) => d.borrowRequests).
 */
export default function useApi(path, params, pick) {
  const [state, setState] = useState({ status: "loading", data: [], total: null, error: "" });
  const [attempt, setAttempt] = useState(0);
  const key = JSON.stringify(params || {});

  useEffect(() => {
    const controller = new AbortController();
    setState((s) => ({ ...s, status: "loading", error: "" }));
    apiGet(path, params, controller.signal)
      .then((payload) => {
        const data = pick(payload) || [];
        setState({ status: data.length ? "success" : "empty", data, total: payload?.total ?? null, error: "" });
      })
      .catch((err) => {
        if (err.name !== "AbortError") setState({ status: "error", data: [], total: null, error: err.message });
      });
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, key, attempt]);

  const reload = useCallback(() => setAttempt((n) => n + 1), []);
  return { ...state, reload };
}

import { useContext } from "react";
import { ReadingListContext } from "../context/ReadingListContext.jsx";

export default function useReadingList() {
  const ctx = useContext(ReadingListContext);
  if (!ctx) throw new Error("useReadingList must be used inside <ReadingListProvider>");
  return ctx;
}

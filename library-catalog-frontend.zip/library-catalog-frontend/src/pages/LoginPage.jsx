import { useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function LoginPage() {
  const { login, status } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || "/";
  const [identity, setIdentity] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (status === "authenticated" && !busy) return <Navigate to={from} replace />;

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      await login(identity.trim(), password);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.status === 401 ? "Wrong email/username or password." : err.message);
      setBusy(false);
    }
  }

  return (
    <form className="form" onSubmit={onSubmit} noValidate>
      <h1>Log in</h1>
      {location.state?.from && <p className="muted">Please log in to continue.</p>}
      {error && <p className="form-error" role="alert">{error}</p>}
      <label>Email or username
        <input value={identity} onChange={(e) => setIdentity(e.target.value)} autoComplete="username" required />
      </label>
      <label>Password
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
      </label>
      <button className="btn" disabled={busy || !identity || !password}>{busy ? "Logging in…" : "Log in"}</button>
      <p className="muted">No account? <Link to="/register" state={location.state}>Register</Link></p>
    </form>
  );
}

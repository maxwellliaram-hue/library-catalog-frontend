import AdminNav from "../../components/AdminNav.jsx";
import DataState from "../../components/DataState.jsx";
import useApi from "../../hooks/useApi.js";
import { fmtDateTime, idOf } from "../../utils.js";

export default function AdminBookingsPage() {
  const { status, data, error, reload } = useApi("/bookings", {}, (d) => d.bookings);
  const spaces = useApi("/bookings/spaces", {}, (d) => d.spaces);
  const nameOf = (id) => spaces.data.find((s) => s.id === id)?.name || id;

  return (
    <>
      <h1 className="page-title">Admin</h1>
      <AdminNav />
      <h2 className="section-title">Space bookings</h2>
      <DataState status={status} error={error} reload={reload} label="Loading bookings…" emptyTitle="No bookings yet" emptyMessage="Space bookings appear here once patrons make them.">
        <div className="table-wrap">
          <table>
            <thead><tr><th>Space</th><th>Date</th><th>Time</th><th>Patron</th><th>Booked at</th></tr></thead>
            <tbody>
              {data.map((b) => (
                <tr key={idOf(b)}>
                  <td>{nameOf(b.space)}</td>
                  <td>{b.date}</td>
                  <td>{b.startTime}–{b.endTime}</td>
                  <td>{b.user?.username || "(deleted user)"}</td>
                  <td>{fmtDateTime(b.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DataState>
    </>
  );
}

import { useState } from "react";
import AdminNav from "../../components/AdminNav.jsx";
import DataState from "../../components/DataState.jsx";
import StatusBadge from "../../components/StatusBadge.jsx";
import useApi from "../../hooks/useApi.js";
import { apiSend } from "../../api.js";
import { fmtDate, fmtDateTime, idOf, money } from "../../utils.js";

// Mirrors the API's allowed transitions (the server enforces them regardless).
const NEXT = { pending: ["approved"], approved: ["late", "returned"], late: ["returned"], returned: [] };

function Row({ r, onChanged, onError }) {
  const options = NEXT[r.status] || [];
  const [target, setTarget] = useState(options[0] || "");
  const [dueAt, setDueAt] = useState("");
  const [busy, setBusy] = useState(false);

  async function apply() {
    setBusy(true);
    onError("");
    try {
      const body = { status: target };
      if (target === "approved" && dueAt) body.dueAt = new Date(`${dueAt}T23:59:00`).toISOString();
      await apiSend(`/borrow-requests/${idOf(r)}`, body, "PATCH");
      await onChanged();
    } catch (err) {
      onError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <tr>
      <td>{r.user?.username || "(deleted user)"}</td>
      <td><strong>{r.bookTitle}</strong><br /><span className="muted">{r.bookAuthor}</span></td>
      <td><StatusBadge status={r.status} /></td>
      <td>{fmtDateTime(r.requestedAt)}</td>
      <td>{fmtDate(r.dueAt)}</td>
      <td>{fmtDate(r.returnedAt)}</td>
      <td>{money(r.fine)}</td>
      <td>
        {options.length === 0 ? <span className="muted">Closed</span> : (
          <div className="controls">
            <select aria-label="New status" value={target} onChange={(e) => setTarget(e.target.value)}>
              {options.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
            {target === "approved" && (
              <input type="date" aria-label="Due date (optional)" title="Due date (optional, default is the standard loan period)" value={dueAt} onChange={(e) => setDueAt(e.target.value)} />
            )}
            <button type="button" className="btn btn--small" onClick={apply} disabled={busy}>{busy ? "Saving…" : "Update"}</button>
          </div>
        )}
      </td>
    </tr>
  );
}

export default function AdminBorrowRequestsPage() {
  const { status, data, error, reload } = useApi("/borrow-requests", {}, (d) => d.borrowRequests);
  const [actionError, setActionError] = useState("");

  return (
    <>
      <h1 className="page-title">Admin</h1>
      <AdminNav />
      <h2 className="section-title">Borrow requests</h2>
      {actionError && <p className="form-error" role="alert">{actionError}</p>}
      <DataState status={status} error={error} reload={reload} label="Loading borrow requests…" emptyTitle="No borrow requests yet" emptyMessage="Requests appear here when patrons ask to borrow a book.">
        <div className="table-wrap">
          <table>
            <thead><tr><th>Patron</th><th>Book</th><th>Status</th><th>Requested</th><th>Due</th><th>Returned</th><th>Fine</th><th>Change status</th></tr></thead>
            <tbody>{data.map((r) => <Row key={idOf(r)} r={r} onChanged={reload} onError={setActionError} />)}</tbody>
          </table>
        </div>
      </DataState>
    </>
  );
}

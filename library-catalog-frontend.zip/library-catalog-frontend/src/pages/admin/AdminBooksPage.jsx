import { useState } from "react";
import AdminNav from "../../components/AdminNav.jsx";
import DataState from "../../components/DataState.jsx";
import useApi from "../../hooks/useApi.js";
import { apiSend } from "../../api.js";
import { genreName } from "../../api.js";
import { idOf } from "../../utils.js";

const PAGE_SIZE = 10;
const BLANK = { title: "", author: "", isbn: "", description: "", coverImage: "", totalCopies: 1, availableCopies: 1, genre: "" };

function BookForm({ initial, genres, onSaved, onCancel }) {
  const editing = Boolean(initial);
  const [form, setForm] = useState(
    initial ? { ...BLANK, ...initial, genre: idOf(initial.genre) || "" } : BLANK
  );
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError("");
    const total = Number(form.totalCopies), avail = Number(form.availableCopies);
    if (!form.title.trim() || !form.author.trim() || !form.isbn.trim() || !form.description.trim() || !form.coverImage.trim()) return setError("Fill in every field.");
    if (!form.genre) return setError("Choose a genre.");
    if (!Number.isInteger(total) || total < 1) return setError("Total copies must be a whole number of at least 1.");
    if (!Number.isInteger(avail) || avail < 0 || avail > total) return setError("Available copies must be between 0 and total copies.");
    setBusy(true);
    try {
      const body = { ...form, totalCopies: total, availableCopies: avail };
      if (editing) await apiSend(`/books/${idOf(initial)}`, body, "PUT");
      else await apiSend("/books", body, "POST");
      await onSaved();
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  return (
    <form className="form form--wide" onSubmit={submit} noValidate>
      <h2>{editing ? "Edit book" : "Add a book"}</h2>
      {error && <p className="form-error" role="alert">{error}</p>}
      <div className="two">
        <label>Title<input value={form.title} onChange={set("title")} /></label>
        <label>Author<input value={form.author} onChange={set("author")} /></label>
        <label>ISBN<input value={form.isbn} onChange={set("isbn")} /></label>
        <label>Genre
          <select value={form.genre} onChange={set("genre")}>
            <option value="">Select a genre…</option>
            {genres.map((g) => <option key={idOf(g)} value={idOf(g)}>{g.name}</option>)}
          </select>
        </label>
        <label>Total copies<input type="number" min="1" value={form.totalCopies} onChange={set("totalCopies")} /></label>
        <label>Available copies<input type="number" min="0" value={form.availableCopies} onChange={set("availableCopies")} /></label>
      </div>
      <label>Cover image URL<input value={form.coverImage} onChange={set("coverImage")} /></label>
      <label>Description<textarea rows="3" value={form.description} onChange={set("description")} /></label>
      <div className="controls">
        <button className="btn" disabled={busy}>{busy ? "Saving…" : editing ? "Save changes" : "Add book"}</button>
        <button type="button" className="btn btn--ghost" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

export default function AdminBooksPage() {
  const [page, setPage] = useState(1);
  const { status, data, total, error, reload } = useApi("/books", { page, limit: PAGE_SIZE }, (d) => d.books);
  const genres = useApi("/genres", {}, (d) => d.genres);
  const [editor, setEditor] = useState(null); // null | "new" | book
  const [actionError, setActionError] = useState("");

  async function remove(book) {
    if (!window.confirm(`Delete "${book.title}"? This can't be undone.`)) return;
    setActionError("");
    try {
      await apiSend(`/books/${idOf(book)}`, undefined, "DELETE");
      // If that was the last book on this page, step back a page.
      if (data.length === 1 && page > 1) setPage(page - 1); else reload();
    } catch (err) {
      setActionError(err.message);
    }
  }

  const saved = async () => { setEditor(null); reload(); };
  const hasNext = total != null && page * PAGE_SIZE < total;

  return (
    <>
      <h1 className="page-title">Admin</h1>
      <AdminNav />
      <div className="row">
        <h2 className="section-title">Books</h2>
        {!editor && <button type="button" className="btn" onClick={() => setEditor("new")}>Add book</button>}
      </div>
      {actionError && <p className="form-error" role="alert">{actionError}</p>}
      {editor && (
        <BookForm
          key={editor === "new" ? "new" : idOf(editor)}
          initial={editor === "new" ? null : editor}
          genres={genres.data}
          onSaved={saved}
          onCancel={() => setEditor(null)}
        />
      )}
      <DataState status={status} error={error} reload={reload} label="Loading books…" emptyTitle="No books in the catalog" emptyMessage="Use “Add book” to create the first one.">
        <div className="table-wrap">
          <table>
            <thead><tr><th>Title</th><th>Author</th><th>Genre</th><th>ISBN</th><th>Copies</th><th>Actions</th></tr></thead>
            <tbody>
              {data.map((b) => (
                <tr key={idOf(b)}>
                  <td><strong>{b.title}</strong></td>
                  <td>{b.author}</td>
                  <td>{genreName(b.genre)}</td>
                  <td>{b.isbn}</td>
                  <td>{b.availableCopies} / {b.totalCopies}</td>
                  <td>
                    <div className="controls">
                      <button type="button" className="btn btn--ghost btn--small" onClick={() => { setActionError(""); setEditor(b); window.scrollTo({ top: 0, behavior: "smooth" }); }}>Edit</button>
                      <button type="button" className="btn btn--danger btn--small" onClick={() => remove(b)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {(page > 1 || hasNext) && (
          <nav className="pager" aria-label="Pagination">
            <button type="button" className="btn" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
            <span>Page {page}</span>
            <button type="button" className="btn" disabled={!hasNext} onClick={() => setPage(page + 1)}>Next</button>
          </nav>
        )}
      </DataState>
    </>
  );
}

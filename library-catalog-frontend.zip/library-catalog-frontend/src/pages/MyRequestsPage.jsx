import { Link } from "react-router-dom";
import DataState from "../components/DataState.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import useApi from "../hooks/useApi.js";
import { fmtDate, idOf, money } from "../utils.js";

export default function MyRequestsPage() {
  const { status, data, error, reload } = useApi("/borrow-requests/mine", {}, (d) => d.borrowRequests);
  return (
    <>
      <h1 className="page-title">My borrow requests</h1>
      <DataState
        status={status} error={error} reload={reload} label="Loading your requests…"
        emptyTitle="No borrow requests yet"
        emptyMessage="Add books to your reading list, then request to borrow them."
      >
        <ul className="list">
          {data.map((r) => (
            <li key={idOf(r)} className="list-item">
              <div className="grow">
                <Link to={`/books/${r.book}`}><strong>{r.bookTitle}</strong></Link>
                <p className="muted">{r.bookAuthor}</p>
                <p className="muted">
                  Requested {fmtDate(r.requestedAt)}
                  {r.dueAt && ` · Due ${fmtDate(r.dueAt)}`}
                  {r.returnedAt && ` · Returned ${fmtDate(r.returnedAt)}`}
                </p>
              </div>
              <div className="right">
                <StatusBadge status={r.status} />
                {r.fine > 0 && <p className="fine">Fine: {money(r.fine)}</p>}
              </div>
            </li>
          ))}
        </ul>
      </DataState>
    </>
  );
}

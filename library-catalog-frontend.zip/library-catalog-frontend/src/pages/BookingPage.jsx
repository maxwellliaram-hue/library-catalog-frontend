import BookingForm from "../components/BookingForm.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function BookingPage() {
  const { user } = useAuth();
  return (
    <>
      <h1 className="page-title">Book a space</h1>
      <p className="muted">Signed in as {user?.username}. Choose a space, a date and a time slot.</p>
      <BookingForm />
    </>
  );
}

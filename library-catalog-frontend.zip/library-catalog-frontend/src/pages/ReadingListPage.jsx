import { Link } from "react-router-dom";
import BorrowButton from "../components/BorrowButton.jsx";
import Cover from "../components/Cover.jsx";
import { Empty } from "../components/StateMessage.jsx";
import useReadingList from "../hooks/useReadingList.js";

export default function ReadingListPage() {
  const { readingList, removeBook, clearList } = useReadingList();

  if (!readingList.length)
    return <Empty title="Your reading list is empty" message="Add books from the catalog and they'll be saved here." action={<Link to="/" className="btn">Browse the catalog</Link>} />;

  return (
    <>
      <div className="row">
        <h1 className="page-title">Reading list ({readingList.length})</h1>
        <button type="button" className="btn btn--ghost" onClick={clearList}>Clear list</button>
      </div>
      <ul className="list">
        {readingList.map((b) => (
          <li key={b.id} className="list-item">
            <Cover src={b.coverImage} title={b.title} className="thumb" />
            <div className="grow">
              <Link to={`/books/${b.id}`}><strong>{b.title}</strong></Link>
              <p className="muted">{b.author}{b.genre ? ` · ${b.genre}` : ""}</p>
            </div>
            <div className="actions">
              <BorrowButton bookId={b.id} />
              <button type="button" className="btn btn--ghost btn--small" onClick={() => removeBook(b.id)}>Remove</button>
            </div>
          </li>
        ))}
      </ul>
    </>
  );
}

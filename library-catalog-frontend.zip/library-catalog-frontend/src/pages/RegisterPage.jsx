import { useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function RegisterPage() {
  const { register, status } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || "/";
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (status === "authenticated" && !busy) return <Navigate to={from} replace />;

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    if (form.username.trim().length < 3) return setError("Username must be at least 3 characters.");
    if (form.password.length < 8) return setError("Password must be at least 8 characters.");
    setBusy(true);
    try {
      await register(form.username.trim(), form.email.trim(), form.password);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.status === 409 ? "That username or email is already registered. Try logging in instead." : err.message);
      setBusy(false);
    }
  }

  return (
    <form className="form" onSubmit={onSubmit} noValidate>
      <h1>Create an account</h1>
      {error && <p className="form-error" role="alert">{error}</p>}
      <label>Username
        <input value={form.username} onChange={set("username")} autoComplete="username" required />
      </label>
      <label>Email
        <input type="email" value={form.email} onChange={set("email")} autoComplete="email" required />
      </label>
      <label>Password (8+ characters)
        <input type="password" value={form.password} onChange={set("password")} autoComplete="new-password" required />
      </label>
      <button className="btn" disabled={busy || !form.username || !form.email || !form.password}>{busy ? "Creating account…" : "Register"}</button>
      <p className="muted">Already registered? <Link to="/login" state={location.state}>Log in</Link></p>
    </form>
  );
}

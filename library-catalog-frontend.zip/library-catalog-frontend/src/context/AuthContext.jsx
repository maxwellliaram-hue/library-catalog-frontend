import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { apiGet, apiSend } from "../api.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [status, setStatus] = useState("loading"); // "loading" | "authenticated" | "anonymous"

  // On app load, ask the API who we are (the httpOnly cookie is sent automatically).
  useEffect(() => {
    const controller = new AbortController();
    apiGet("/users/profile", {}, controller.signal)
      .then((data) => { setUser(data.user); setStatus("authenticated"); })
      .catch((err) => { if (err.name !== "AbortError") { setUser(null); setStatus("anonymous"); } });
    return () => controller.abort();
  }, []);

  const login = useCallback(async (identity, password) => {
    const data = await apiSend("/auth/login", { email: identity, password });
    setUser(data.user);
    setStatus("authenticated"); // routes unlock immediately, no page reload
    return data.user;
  }, []);

  const register = useCallback(async (username, email, password) => {
    await apiSend("/auth/register", { username, email, password });
    return login(email, password); // the API doesn't log in on register, so do it now
  }, [login]);

  const logout = useCallback(async () => {
    try { await apiSend("/auth/logout"); } catch { /* clear local state regardless */ }
    setUser(null);
    setStatus("anonymous");
  }, []);

  return <AuthContext.Provider value={{ user, status, login, register, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}

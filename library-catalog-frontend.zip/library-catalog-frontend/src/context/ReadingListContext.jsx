import { createContext, useEffect, useReducer } from "react";
import { coverOf, genreName } from "../api.js";

export const ReadingListContext = createContext(null);

const STORAGE_KEY = "library.readingList.v1";

function load() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return []; // corrupted JSON or storage unavailable
  }
}

function reducer(state, action) {
  switch (action.type) {
    case "add":
      return state.some((b) => b.id === action.book.id) ? state : [...state, action.book];
    case "remove":
      return state.filter((b) => b.id !== action.id);
    case "clear":
      return [];
    default:
      return state;
  }
}

// Store only what the list needs to render, not the whole API object.
const snapshot = (book) => ({
  id: book.id ?? book._id,
  title: book.title,
  author: book.author,
  genre: genreName(book.genre),
  coverImage: coverOf(book),
});

export function ReadingListProvider({ children }) {
  const [readingList, dispatch] = useReducer(reducer, undefined, load);

  // Persist on every change so the list survives a refresh.
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(readingList)); } catch { /* quota/private mode */ }
  }, [readingList]);

  const value = {
    readingList,
    addBook: (book) => dispatch({ type: "add", book: snapshot(book) }),
    removeBook: (id) => dispatch({ type: "remove", id }),
    clearList: () => dispatch({ type: "clear" }),
    hasBook: (id) => readingList.some((b) => b.id === id),
  };
  return <ReadingListContext.Provider value={value}>{children}</ReadingListContext.Provider>;
}

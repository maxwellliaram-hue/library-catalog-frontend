const BASE = (import.meta.env.VITE_API_URL || "http://localhost:3000/api").replace(/\/$/, "");

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

// The API authenticates with an httpOnly cookie, so every request must send credentials.
async function request(url, options = {}) {
  let res;
  try {
    res = await fetch(url, { credentials: "include", ...options });
  } catch (err) {
    if (err.name === "AbortError") throw err;
    throw new ApiError("Could not reach the server. Check your connection and try again.", 0);
  }
  let body = null;
  try { body = await res.json(); } catch { /* empty or non-JSON body */ }
  if (!res.ok) throw new ApiError(body?.message || `The server responded with an error (${res.status}).`, res.status);
  return body;
}

export function apiGet(path, params = {}, signal) {
  const url = new URL(BASE + path);
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, v);
  });
  return request(url, { signal });
}

export function apiSend(path, body, method = "POST") {
  return request(BASE + path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body ?? {}),
  });
}

// The API shape may vary: accept a bare array or { data | items | books, total }.
export function normalizeList(payload) {
  if (Array.isArray(payload)) return { items: payload, total: null };
  const items = payload?.data ?? payload?.items ?? payload?.books ?? [];
  return { items, total: payload?.total ?? payload?.count ?? null };
}

export const coverOf = (b) => b?.coverUrl ?? b?.cover_url ?? b?.cover ?? b?.coverImage ?? b?.image ?? "";
export const genreName = (g) => (typeof g === "string" ? g : g?.name ?? g?.genre ?? "");

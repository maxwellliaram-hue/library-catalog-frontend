import { Link, Navigate, NavLink, Route, Routes } from "react-router-dom";
import CatalogPage from "./pages/CatalogPage.jsx";
import BookDetailPage from "./pages/BookDetailPage.jsx";
import LoginPage from "./pages/LoginPage.jsx";
import RegisterPage from "./pages/RegisterPage.jsx";
import ReadingListPage from "./pages/ReadingListPage.jsx";
import BookingPage from "./pages/BookingPage.jsx";
import MyRequestsPage from "./pages/MyRequestsPage.jsx";
import AdminBooksPage from "./pages/admin/AdminBooksPage.jsx";
import AdminBorrowRequestsPage from "./pages/admin/AdminBorrowRequestsPage.jsx";
import AdminBookingsPage from "./pages/admin/AdminBookingsPage.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import { useAuth } from "./context/AuthContext.jsx";
import useReadingList from "./hooks/useReadingList.js";

function Header() {
  const { user, status, logout } = useAuth();
  const { readingList } = useReadingList();
  return (
    <header className="site-header">
      <Link to="/" className="brand">Library Catalog</Link>
      <nav className="nav" aria-label="Main">
        <NavLink to="/" end>Catalog</NavLink>
        <NavLink to="/reading-list">Reading list ({readingList.length})</NavLink>
        <NavLink to="/booking">Book a space</NavLink>
        {status === "authenticated" ? (
          <>
            <NavLink to="/my-requests">My requests</NavLink>
            {user.role === "librarian" && <NavLink to="/admin/books">Admin</NavLink>}
            <span className="who">{user.username}</span>
            <button type="button" className="link-btn" onClick={logout}>Log out</button>
          </>
        ) : status === "anonymous" ? (
          <>
            <NavLink to="/login">Log in</NavLink>
            <NavLink to="/register">Register</NavLink>
          </>
        ) : null}
      </nav>
    </header>
  );
}

export default function App() {
  return (
    <>
      <Header />
      <main className="container">
        <Routes>
          <Route path="/" element={<CatalogPage />} />
          <Route path="/books/:id" element={<BookDetailPage />} />
          <Route path="/reading-list" element={<ReadingListPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/booking" element={<ProtectedRoute><BookingPage /></ProtectedRoute>} />
          <Route path="/my-requests" element={<ProtectedRoute><MyRequestsPage /></ProtectedRoute>} />
          <Route path="/admin" element={<Navigate to="/admin/books" replace />} />
          <Route path="/admin/books" element={<ProtectedRoute role="librarian"><AdminBooksPage /></ProtectedRoute>} />
          <Route path="/admin/borrow-requests" element={<ProtectedRoute role="librarian"><AdminBorrowRequestsPage /></ProtectedRoute>} />
          <Route path="/admin/bookings" element={<ProtectedRoute role="librarian"><AdminBookingsPage /></ProtectedRoute>} />
          <Route
            path="*"
            element={
              <div className="state" role="alert">
                <h2>Page not found</h2>
                <Link to="/">Back to the catalog</Link>
              </div>
            }
          />
        </Routes>
      </main>
    </>
  );
}

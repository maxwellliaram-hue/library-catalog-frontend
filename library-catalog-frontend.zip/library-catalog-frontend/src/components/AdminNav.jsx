import { NavLink } from "react-router-dom";

export default function AdminNav() {
  return (
    <nav className="tabs" aria-label="Admin">
      <NavLink to="/admin/books">Books</NavLink>
      <NavLink to="/admin/borrow-requests">Borrow requests</NavLink>
      <NavLink to="/admin/bookings">Bookings</NavLink>
    </nav>
  );
}

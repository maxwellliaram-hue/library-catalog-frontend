import { Empty, ErrorMessage, Loading } from "./StateMessage.jsx";

// Renders the loading / error / empty state, or children when there is data.
export default function DataState({ status, error, reload, emptyTitle, emptyMessage, label, children }) {
  if (status === "loading") return <Loading label={label} />;
  if (status === "error") return <ErrorMessage title="Couldn't load data" message={error} onRetry={reload} />;
  if (status === "empty") return <Empty title={emptyTitle} message={emptyMessage} />;
  return children;
}

import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { apiSend } from "../api.js";
import { useAuth } from "../context/AuthContext.jsx";

export default function BorrowButton({ bookId }) {
  const { status } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [state, setState] = useState({ phase: "idle", message: "" });

  async function request() {
    if (status !== "authenticated") return navigate("/login", { state: { from: location } });
    setState({ phase: "busy", message: "" });
    try {
      await apiSend("/borrow-requests", { bookId });
      setState({ phase: "done", message: "" });
    } catch (err) {
      setState({ phase: "error", message: err.message });
    }
  }

  if (state.phase === "done")
    return <p className="ok">Requested. <Link to="/my-requests">View my requests</Link></p>;

  return (
    <div className="borrow">
      <button type="button" className="btn btn--small" onClick={request} disabled={state.phase === "busy"}>
        {state.phase === "busy" ? "Requesting…" : "Request to borrow"}
      </button>
      {state.phase === "error" && <p className="inline-error" role="alert">{state.message}</p>}
    </div>
  );
}

import { useState } from "react";
import { apiSend } from "../api.js";
import useApi from "../hooks/useApi.js";

const localToday = () => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};

const EMPTY = { space: "", date: "", startTime: "", endTime: "" };

export default function BookingForm() {
  const spaces = useApi("/bookings/spaces", {}, (d) => d.spaces);
  const [booking, setBooking] = useState(EMPTY);
  const [error, setError] = useState("");
  const [confirmed, setConfirmed] = useState(null);
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setBooking({ ...booking, [k]: e.target.value });

  async function onSubmit(e) {
    e.preventDefault();
    setConfirmed(null);
    if (!booking.space || !booking.date || !booking.startTime || !booking.endTime) return setError("Fill in every field.");
    if (booking.endTime <= booking.startTime) return setError("End time must be after the start time.");
    setError("");
    setBusy(true);
    try {
      // The server is the source of truth: it rejects overlapping bookings with a 409.
      await apiSend("/bookings", booking);
      setConfirmed(booking);
      setBooking(EMPTY);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (spaces.status === "loading") return <p className="muted" role="status">Loading spaces…</p>;
  if (spaces.status === "error")
    return <p className="form-error" role="alert">Couldn't load spaces: {spaces.error} <button type="button" className="link-btn" onClick={spaces.reload}>Try again</button></p>;

  return (
    <form className="form" onSubmit={onSubmit} noValidate>
      {error && <p className="form-error" role="alert">{error}</p>}
      <label>Space
        <select value={booking.space} onChange={set("space")}>
          <option value="">Select a space…</option>
          {spaces.data.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </label>
      <label>Date
        <input type="date" min={localToday()} value={booking.date} onChange={set("date")} />
      </label>
      <div className="two">
        <label>Start time<input type="time" value={booking.startTime} onChange={set("startTime")} /></label>
        <label>End time<input type="time" value={booking.endTime} onChange={set("endTime")} /></label>
      </div>
      <button className="btn" disabled={busy}>{busy ? "Booking…" : "Book space"}</button>

      {confirmed && (
        <div className="notice" role="status">
          <strong>Booked</strong>
          <p>{spaces.data.find((s) => s.id === confirmed.space)?.name} on {confirmed.date}, {confirmed.startTime}–{confirmed.endTime}.</p>
        </div>
      )}
    </form>
  );
}

import { Link, Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { Loading } from "./StateMessage.jsx";

// `role` (optional) additionally restricts the route, e.g. role="librarian" for admin pages.
export default function ProtectedRoute({ children, role }) {
  const { status, user } = useAuth();
  const location = useLocation();

  if (status === "loading") return <Loading label="Checking your session…" />;
  if (status !== "authenticated") return <Navigate to="/login" replace state={{ from: location }} />;
  if (role && user.role !== role) {
    return (
      <div className="state" role="alert">
        <h2>Librarians only</h2>
        <p>Your account doesn't have access to this page.</p>
        <Link to="/" className="btn">Back to the catalog</Link>
      </div>
    );
  }
  return children;
}

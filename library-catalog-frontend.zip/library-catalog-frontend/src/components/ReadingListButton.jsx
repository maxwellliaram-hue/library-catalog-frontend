import useReadingList from "../hooks/useReadingList.js";

export default function ReadingListButton({ book, className = "" }) {
  const { hasBook, addBook, removeBook } = useReadingList();
  const id = book.id ?? book._id;
  const saved = hasBook(id);
  return (
    <button
      type="button"
      className={`btn ${saved ? "btn--ghost" : ""} ${className}`}
      aria-pressed={saved}
      onClick={() => (saved ? removeBook(id) : addBook(book))}
    >
      {saved ? "Remove from reading list" : "Add to reading list"}
    </button>
  );
}

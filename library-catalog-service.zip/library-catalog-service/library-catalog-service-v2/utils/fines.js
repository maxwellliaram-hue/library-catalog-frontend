const MS_PER_DAY = 24 * 60 * 60 * 1000;

function centsPerDay() {
  const n = Number(process.env.FINE_PER_DAY_CENTS);
  return Number.isFinite(n) && n >= 0 ? n : 25;
}

/** Whole days late; any part of a day counts as a full day. 0 if on time. */
function daysLate(dueAt, returnedAt) {
  if (!dueAt || !returnedAt) return 0;
  const lateMs = new Date(returnedAt).getTime() - new Date(dueAt).getTime();
  return lateMs > 0 ? Math.ceil(lateMs / MS_PER_DAY) : 0;
}

/** Fine in dollars: daysLate * rate. Deterministic: depends only on the two dates and the rate. */
function calculateFine(dueAt, returnedAt, rateCents = centsPerDay()) {
  return (daysLate(dueAt, returnedAt) * rateCents) / 100;
}

module.exports = { calculateFine, daysLate, MS_PER_DAY };

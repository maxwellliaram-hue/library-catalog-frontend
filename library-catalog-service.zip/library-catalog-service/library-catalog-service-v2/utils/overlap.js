const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

const isValidTime = (t) => typeof t === "string" && TIME_RE.test(t);
const isValidDate = (d) => {
  if (typeof d !== "string" || !DATE_RE.test(d)) return false;
  const parsed = new Date(`${d}T00:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === d; // rejects 2026-02-31
};
const toMinutes = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };

/**
 * Half-open ranges [start, end): two ranges overlap when each starts before the other ends.
 * Covers exact duplicates, partial overlaps on either side, containment either way.
 * Back-to-back bookings (one ends 10:00, next starts 10:00) do NOT overlap.
 */
function rangesOverlap(aStart, aEnd, bStart, bEnd) {
  return toMinutes(aStart) < toMinutes(bEnd) && toMinutes(bStart) < toMinutes(aEnd);
}

module.exports = { isValidTime, isValidDate, toMinutes, rangesOverlap };

const jwt = require("jsonwebtoken");
const User = require("../models/User");

function extractToken(req) {
  if (req.cookies && req.cookies.token) return req.cookies.token;
  const header = (req.headers && req.headers.authorization) || "";
  const [scheme, value] = header.split(" ");
  return scheme === "Bearer" && value ? value : null;
}

// 401: no/invalid/expired token, or the user no longer exists.
async function requireAuth(req, res, next) {
  try {
    const token = extractToken(req);
    if (!token) return res.status(401).json({ message: "Authentication required" });
    let payload;
    try {
      payload = jwt.verify(token, process.env.JWT_SECRET);
    } catch {
      return res.status(401).json({ message: "Invalid or expired token" });
    }
    const user = await User.findById(payload.sub); // reload so the *current* role is used
    if (!user) return res.status(401).json({ message: "Invalid or expired token" });
    req.user = user;
    return next();
  } catch (error) {
    return next(error);
  }
}

// 403: authenticated, but wrong role.
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) return res.status(403).json({ message: "Forbidden: insufficient role" });
    return next();
  };
}

module.exports = { requireAuth, requireRole };

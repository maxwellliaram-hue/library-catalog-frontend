const test = require("node:test");
const assert = require("node:assert/strict");
const { calculateFine, daysLate } = require("../utils/fines");

const due = new Date("2026-03-10T12:00:00Z");
const after = (ms) => new Date(due.getTime() + ms);
const DAY = 86400000;

test("no fine when returned before or exactly at the due time", () => {
  assert.equal(calculateFine(due, after(-DAY)), 0);
  assert.equal(calculateFine(due, due), 0);
});
test("any part of a day late counts as a full day at $0.25", () => {
  assert.equal(calculateFine(due, after(1)), 0.25);
  assert.equal(calculateFine(due, after(DAY)), 0.25);
  assert.equal(calculateFine(due, after(DAY + 1)), 0.5);
});
test("multi-day lateness", () => {
  assert.equal(daysLate(due, after(3 * DAY)), 3);
  assert.equal(calculateFine(due, after(3 * DAY)), 0.75);
  assert.equal(calculateFine(due, after(10 * DAY - 5000)), 2.5);
});
test("missing dates produce no fine", () => {
  assert.equal(calculateFine(null, new Date()), 0);
  assert.equal(calculateFine(due, null), 0);
});
test("rate is a parameter, so results are deterministic", () => {
  assert.equal(calculateFine(due, after(2 * DAY), 100), 2);
});

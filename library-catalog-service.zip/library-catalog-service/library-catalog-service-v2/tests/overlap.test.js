const test = require("node:test");
const assert = require("node:assert/strict");
const { rangesOverlap, isValidDate, isValidTime } = require("../utils/overlap");

// Existing booking is 10:00-12:00
const clash = (s, e) => rangesOverlap(s, e, "10:00", "12:00");

test("exact duplicate overlaps", () => assert.equal(clash("10:00", "12:00"), true));
test("partial overlap at the start overlaps", () => assert.equal(clash("09:00", "10:30"), true));
test("partial overlap at the end overlaps", () => assert.equal(clash("11:30", "13:00"), true));
test("new range inside existing overlaps", () => assert.equal(clash("10:30", "11:00"), true));
test("new range containing existing overlaps", () => assert.equal(clash("09:00", "13:00"), true));
test("one-minute overlap is still an overlap", () => {
  assert.equal(clash("11:59", "13:00"), true);
  assert.equal(clash("09:00", "10:01"), true);
});
test("back-to-back bookings do not overlap", () => {
  assert.equal(clash("09:00", "10:00"), false);
  assert.equal(clash("12:00", "13:00"), false);
});
test("disjoint ranges do not overlap", () => assert.equal(clash("13:00", "14:00"), false));
test("validators", () => {
  assert.equal(isValidDate("2026-02-31"), false);
  assert.equal(isValidDate("2026-02-28"), true);
  assert.equal(isValidTime("24:00"), false);
  assert.equal(isValidTime("9:00"), false);
  assert.equal(isValidTime("09:00"), true);
});

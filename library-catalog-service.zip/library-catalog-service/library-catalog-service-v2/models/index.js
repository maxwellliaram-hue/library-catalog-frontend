module.exports = {
  Genre: require("./Genre"),
  Book: require("./Book"),
  User: require("./User"),
  BorrowRequest: require("./BorrowRequest"),
  Booking: require("./Booking"),
};

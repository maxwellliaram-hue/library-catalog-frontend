const mongoose = require("mongoose");
const SPACES = require("../constants/spaces");

const booking = new mongoose.Schema({
  space: { type: String, required: true, enum: SPACES.map((s) => s.id) },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  date: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ },       // YYYY-MM-DD
  startTime: { type: String, required: true, match: /^([01]\d|2[0-3]):[0-5]\d$/ }, // 24h HH:MM
  endTime: { type: String, required: true, match: /^([01]\d|2[0-3]):[0-5]\d$/ },
}, { timestamps: true, toJSON: { virtuals: true, versionKey: false } });

booking.index({ space: 1, date: 1 });

module.exports = mongoose.model("Booking", booking);

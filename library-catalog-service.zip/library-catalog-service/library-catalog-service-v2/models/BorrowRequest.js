const mongoose = require("mongoose");

const STATUSES = ["pending", "approved", "returned", "late"];

const borrowRequestSchema = new mongoose.Schema({
  book: { type: mongoose.Schema.Types.ObjectId, ref: "Book", required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  // Snapshot of the catalog entry at request time. The Book can later be edited or
  // deleted; the borrowing record must still show what the patron actually asked for.
  bookTitle: { type: String, required: true },
  bookAuthor: { type: String, required: true },
  status: { type: String, enum: STATUSES, default: "pending", required: true },
  requestedAt: { type: Date, default: Date.now, required: true },
  dueAt: { type: Date, default: null },      // set when a librarian approves
  returnedAt: { type: Date, default: null }, // set by the server when marked returned
  fine: { type: Number, default: 0, min: 0 }, // dollars; only ever written by the server
}, { toJSON: { virtuals: true, versionKey: false } });

borrowRequestSchema.index({ user: 1, requestedAt: -1 });
borrowRequestSchema.index({ book: 1, status: 1 });

module.exports = mongoose.model("BorrowRequest", borrowRequestSchema);
module.exports.STATUSES = STATUSES;

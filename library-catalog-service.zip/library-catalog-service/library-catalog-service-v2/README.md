# Library Catalog Service

A MongoDB-backed library catalog API with bcrypt password hashing, JWT authentication, and librarian-only catalog management.

## Setup

1. Install Node.js (18+) and MongoDB.
2. Copy `.env.example` to `.env` and set `MONGODB_URI` and a strong, private `JWT_SECRET` (at least 32 random characters).
3. Install dependencies: `npm install`.
4. (CORS) set `CLIENT_ORIGIN` to the frontend origin, default `http://localhost:5173`.
5. Seed sample catalog data and the development librarian: `npm run seed`.
6. Start the API: `npm start`.

The API listens on `http://localhost:3000`. Never commit your real `.env` file. The seeded credentials below are for local assignment testing only; change them before any deployment.

## Seeded librarian (development only)

- Username: `librarian`
- Email: `librarian@library.local`
- Password: `LibraryAdmin123!`

The seed script hashes this password with bcrypt (12 salt rounds) before saving it. It is idempotent and maintains one librarian account; it does not store a plaintext password. Override the values with the `SEED_LIBRARIAN_*` environment variables. Do not use these public test credentials in production.

## API endpoints

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create a patron account; clients cannot assign themselves a role |
| POST | `/api/auth/login` | Public | Verify credentials and set an httpOnly JWT cookie |
| POST | `/api/auth/logout` | Public | Clear the authentication cookie in the browser |
| GET | `/api/users/profile` | Authenticated | Return only the caller's own profile |
| GET | `/api/books` | Public | List books; supports `?search=`, `?genre=`, `?page=`, `?limit=` |
| POST | `/api/books` | Librarian | Create a book |
| PUT | `/api/books/:id` | Librarian | Update a book |
| DELETE | `/api/books/:id` | Librarian | Delete a book (409 if it has open requests/loans) |
| GET | `/api/books/:id` | Public | One book |
| GET | `/api/genres` | Public | List genres |
| POST | `/api/borrow-requests` | Authenticated | Create a `pending` request for `{ bookId }` |
| GET | `/api/borrow-requests/mine` | Authenticated | The caller's own requests |
| GET | `/api/borrow-requests` | Librarian | All requests |
| PATCH | `/api/borrow-requests/:id` | Librarian | Change status (`{ status, dueAt? }`); fine computed by the server |
| GET | `/api/bookings/spaces` | Public | Bookable spaces |
| POST | `/api/bookings` | Authenticated | Book `{ space, date, startTime, endTime }`; 409 on overlap |
| GET | `/api/bookings/mine` | Authenticated | The caller's bookings |
| GET | `/api/bookings` | Librarian | All bookings |

### Authorization behavior

- No token or an invalid/expired token on a protected route returns **401 Unauthorized**.
- A valid patron token on a librarian-only route returns **403 Forbidden**.
- A valid librarian token can perform catalog mutations.
- Registration always creates a `patron`; role assignment is controlled by the seed/admin process.
- The profile endpoint derives the user identity from the verified JWT subject and never accepts a user ID from the request.

For API clients that do not use cookies, middleware also accepts `Authorization: Bearer <token>`; the login endpoint intentionally issues the token as an httpOnly cookie.

## Token Storage and Security Trade-off

This API stores the JWT in a browser **httpOnly cookie**, rather than localStorage. After a successful login, the server sets a cookie named `token` with the `httpOnly` flag, `SameSite=Strict`, a one-hour lifetime, and the `Secure` flag in production. The browser automatically sends the cookie with matching requests, while frontend JavaScript cannot read its value. This reduces the chance that an injected script in a Cross-Site Scripting (XSS) attack can steal the token. The JWT contains the user's database ID as its subject and is signed with the server-only `JWT_SECRET`; protected requests verify the signature and reload the user from MongoDB so the current role is used.

The trade-off is that cookies are sent automatically by browsers, which creates a Cross-Site Request Forgery (CSRF) concern. This project uses `SameSite=Strict` as a browser-level mitigation and the API should additionally enforce trusted origins/CSRF tokens if it is deployed in a cross-site frontend configuration. The `Secure` flag is enabled in production so the cookie is sent only over HTTPS. By comparison, localStorage is simple to use with bearer headers, but any JavaScript running on the page can read it, making token theft through XSS easier. An httpOnly cookie is therefore the selected option for this API, with stricter cookie and origin configuration required for deployment.

Logout is client-side cookie invalidation: `POST /api/auth/logout` sends a matching expired cookie using `Set-Cookie`. This project does not maintain a server-side token blocklist, so a copied token remains valid until its one-hour expiry; the browser's own cookie is cleared immediately.

## Existing catalog schema

Book metadata is stored in the `Book` collection. Genre names and slugs are normalized in the `Genre` collection and referenced by ObjectId from each book.

## Borrow requests

Lifecycle: `pending` → `approved` → `returned`, with an optional `approved` → `late` step. Any other transition is rejected with 409.

- **Creating** (`POST /api/borrow-requests`): the user comes from the login token, and the title/author snapshot is copied from the Book in the database. The request is rejected with **409 if the book has zero `availableCopies`**, or if the patron already has an open request/loan for that book.
- **Approving** sets `dueAt` (14 days from now by default, `LOAN_DAYS`; a librarian may pass an explicit `dueAt`, e.g. to backdate for testing) and atomically takes one copy off `availableCopies`. If the last copy was just taken by someone else, it is rejected with 409.
- **Marking late** is only allowed once the due date has passed.
- **Returning** sets `returnedAt` to the server's current time, computes the fine, and gives the copy back.
- **Only librarians** can PATCH (401 without a login, 403 for a patron). The body's `fine` and `returnedAt` are ignored.

### Fine calculation rule

**$0.25 per day late (`FINE_PER_DAY_CENTS=25`), counting any part of a day as a full day.** The server works out `daysLate = ceil((returnedAt - dueAt) / 24h)` when the book comes back after `dueAt`, and `fine = daysLate × $0.25`. On time (or exactly at the due time) is `$0.00`. Examples: 1 minute late = $0.25, 1 day + 1 minute late = $0.50, 3 days late = $0.75. The calculation uses only the stored due date and the server clock, so a client can't influence it. See `utils/fines.js` and `tests/fines.test.js`.

## Space bookings: overlap check

Times are stored as 24-hour `HH:MM` and dates as `YYYY-MM-DD`. When `POST /api/bookings` arrives, the server loads every booking for the same space on the same date and compares the new time range against each one. Two ranges **overlap if each one starts before the other ends** (`newStart < existingEnd` and `existingStart < newEnd`). That catches exact duplicates, partial overlaps at either end, a new booking inside an existing one, and a new booking that swallows an existing one. A booking that starts exactly when another ends (10:00 right after a 09:00–10:00 booking) is allowed. Any overlap returns **409** naming the conflicting slot. Input is validated server-side too (known space, real date, valid times, end after start). See `utils/overlap.js` and `tests/overlap.test.js`.

Known limitation: the check and the insert are two steps, so two requests for the same slot arriving in the same few milliseconds could both pass. A production system would close that with a transaction or a per-slot lock.

## Tests

`npm test` runs unit tests for the auth middleware, the fine calculation and the overlap logic.

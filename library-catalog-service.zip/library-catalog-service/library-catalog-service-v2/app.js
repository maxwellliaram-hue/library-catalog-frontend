const express = require("express");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const dotenv = require("dotenv");
const mongoose = require("mongoose");

dotenv.config();

const app = express();
// The API authenticates with an httpOnly cookie, so CORS must name the exact frontend origin and allow credentials.
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173", credentials: true }));
app.use(express.json({ limit: "10kb" }));
app.use(cookieParser());

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
app.use("/api/auth", require("./routes/auth"));
app.use("/api/users", require("./routes/users"));
app.use("/api/genres", require("./routes/genres"));
app.use("/api/books", require("./routes/books"));
app.use("/api/borrow-requests", require("./routes/borrowRequests"));
app.use("/api/bookings", require("./routes/bookings"));

app.use((err, _req, res, _next) => {
  if (err.name === "ValidationError") return res.status(400).json({ message: Object.values(err.errors).map((e) => e.message).join(" ") });
  if (err.name === "CastError") return res.status(400).json({ message: `Invalid value for ${err.path}` });
  if (err.code === 11000) return res.status(409).json({ message: "A record with that unique value already exists" });
  if (!err.status) console.error(err);
  res.status(err.status || 500).json({ message: err.status ? err.message : "Internal server error" });
});

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  if (!process.env.MONGODB_URI) throw new Error("MONGODB_URI is required");
  mongoose.connect(process.env.MONGODB_URI)
    .then(() => app.listen(PORT, () => console.log(`Library API listening on port ${PORT}`)))
    .catch((error) => {
      console.error("Database connection failed:", error.message);
      process.exit(1);
    });
}

module.exports = app;

// Bookable spaces. Kept in one place so the API validates against the same list it serves.
module.exports = [
  { id: "study-room-1", name: "Study Room 1 (4 people)" },
  { id: "study-room-2", name: "Study Room 2 (6 people)" },
  { id: "quiet-booth", name: "Quiet Booth (1 person)" },
  { id: "computer-lab", name: "Computer Lab" },
];

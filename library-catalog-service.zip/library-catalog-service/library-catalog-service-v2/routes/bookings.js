const express = require("express");
const Booking = require("../models/Booking");
const SPACES = require("../constants/spaces");
const { requireAuth, requireRole } = require("../middleware/auth");
const { isValidDate, isValidTime, rangesOverlap, toMinutes } = require("../utils/overlap");

const router = express.Router();
const spaceName = (id) => SPACES.find((s) => s.id === id)?.name || id;

router.get("/spaces", (_req, res) => res.json({ spaces: SPACES }));

// POST /api/bookings  { space, date: "YYYY-MM-DD", startTime: "HH:MM", endTime: "HH:MM" }
router.post("/", requireAuth, async (req, res, next) => {
  try {
    const { space, date, startTime, endTime } = req.body || {};
    if (!SPACES.some((s) => s.id === space)) return res.status(400).json({ message: "Unknown space" });
    if (!isValidDate(date)) return res.status(400).json({ message: "date must be a real date in YYYY-MM-DD format" });
    if (!isValidTime(startTime) || !isValidTime(endTime)) return res.status(400).json({ message: "startTime and endTime must be HH:MM (24-hour)" });
    if (toMinutes(endTime) <= toMinutes(startTime)) return res.status(400).json({ message: "endTime must be after startTime" });

    // Overlap check against every booking for the same space on the same day.
    const sameDay = await Booking.find({ space, date }).select("startTime endTime");
    const clash = sameDay.find((b) => rangesOverlap(startTime, endTime, b.startTime, b.endTime));
    if (clash) {
      return res.status(409).json({
        message: `${spaceName(space)} is already booked on ${date} from ${clash.startTime} to ${clash.endTime}. Choose a different time or space.`,
      });
    }

    const booking = await Booking.create({ space, date, startTime, endTime, user: req.user._id });
    res.status(201).json({ booking });
  } catch (error) { next(error); }
});

router.get("/mine", requireAuth, async (req, res, next) => {
  try {
    res.json({ bookings: await Booking.find({ user: req.user._id }).sort({ date: 1, startTime: 1 }) });
  } catch (error) { next(error); }
});

router.get("/", requireAuth, requireRole("librarian"), async (_req, res, next) => {
  try {
    res.json({ bookings: await Booking.find().populate("user", "username email").sort({ date: 1, startTime: 1 }) });
  } catch (error) { next(error); }
});

module.exports = router;

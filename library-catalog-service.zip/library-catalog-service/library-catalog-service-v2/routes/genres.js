const express = require("express");
const Genre = require("../models/Genre");

const router = express.Router();

router.get("/", async (_req, res, next) => {
  try {
    res.json({ genres: await Genre.find().select("name slug").sort({ name: 1 }) });
  } catch (error) { next(error); }
});

module.exports = router;

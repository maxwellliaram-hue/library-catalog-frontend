const express = require("express");
const mongoose = require("mongoose");
const Book = require("../models/Book");
const Genre = require("../models/Genre");
const BorrowRequest = require("../models/BorrowRequest");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();
const librarianOnly = [requireAuth, requireRole("librarian")];
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const EDITABLE = ["title", "author", "isbn", "description", "coverImage", "totalCopies", "availableCopies", "genre"];
const bad = (res, message) => res.status(400).json({ message });

// Public catalog reads: GET /api/books?search=&genre=&page=&limit=
router.get("/", async (req, res, next) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 12));
    const filter = {};

    if (req.query.search) {
      const rx = new RegExp(escapeRegex(String(req.query.search).trim()), "i");
      filter.$or = [{ title: rx }, { author: rx }];
    }
    if (req.query.genre) {
      const wanted = String(req.query.genre).trim();
      const genre = await Genre.findOne({ $or: [{ name: new RegExp(`^${escapeRegex(wanted)}$`, "i") }, { slug: wanted.toLowerCase() }] });
      if (!genre) return res.json({ books: [], total: 0, page, limit });
      filter.genre = genre._id;
    }

    const [books, total] = await Promise.all([
      Book.find(filter).populate("genre", "name slug").sort({ title: 1 }).skip((page - 1) * limit).limit(limit),
      Book.countDocuments(filter),
    ]);
    res.json({ books, total, page, limit });
  } catch (error) { next(error); }
});

router.get("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return bad(res, "Invalid book id");
    const book = await Book.findById(req.params.id).populate("genre", "name slug");
    if (!book) return res.status(404).json({ message: "Book not found" });
    res.json({ book });
  } catch (error) { next(error); }
});

async function genreExists(id) {
  return mongoose.isValidObjectId(id) && (await Genre.exists({ _id: id }));
}

router.post("/", ...librarianOnly, async (req, res, next) => {
  try {
    const data = {};
    EDITABLE.forEach((k) => { if (req.body?.[k] !== undefined) data[k] = req.body[k]; });
    if (!(await genreExists(data.genre))) return bad(res, "A valid genre is required");
    const book = await Book.create(data);
    await book.populate("genre", "name slug");
    res.status(201).json({ book });
  } catch (error) { next(error); }
});

// Load-modify-save (not findByIdAndUpdate) so document validators run with the full document:
// the availableCopies <= totalCopies check needs `this.totalCopies`, which is undefined in update validators.
router.put("/:id", ...librarianOnly, async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return bad(res, "Invalid book id");
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: "Book not found" });
    if (req.body?.genre !== undefined && !(await genreExists(req.body.genre))) return bad(res, "A valid genre is required");
    EDITABLE.forEach((k) => { if (req.body?.[k] !== undefined) book.set(k, req.body[k]); });
    await book.save();
    await book.populate("genre", "name slug");
    res.json({ book });
  } catch (error) { next(error); }
});

router.delete("/:id", ...librarianOnly, async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return bad(res, "Invalid book id");
    const active = await BorrowRequest.exists({ book: req.params.id, status: { $in: ["pending", "approved", "late"] } });
    if (active) return res.status(409).json({ message: "This book has open borrow requests or loans. Resolve them before deleting it." });
    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) return res.status(404).json({ message: "Book not found" });
    res.json({ message: "Book deleted", id: book._id });
  } catch (error) { next(error); }
});

module.exports = router;

const express = require("express");
const mongoose = require("mongoose");
const Book = require("../models/Book");
const BorrowRequest = require("../models/BorrowRequest");
const { requireAuth, requireRole } = require("../middleware/auth");
const { calculateFine } = require("../utils/fines");

const router = express.Router();
const librarianOnly = [requireAuth, requireRole("librarian")];
const ACTIVE = ["pending", "approved", "late"];
const LOAN_DAYS = () => (Number(process.env.LOAN_DAYS) > 0 ? Number(process.env.LOAN_DAYS) : 14);

// Allowed status changes. Anything else is a 409 so records can't be moved into nonsense states.
const TRANSITIONS = {
  pending: ["approved"],
  approved: ["late", "returned"],
  late: ["returned"],
  returned: [],
};

// POST /api/borrow-requests  { bookId }  -> pending request for the logged-in patron
router.post("/", requireAuth, async (req, res, next) => {
  try {
    const { bookId } = req.body || {};
    if (!mongoose.isValidObjectId(bookId)) return res.status(400).json({ message: "A valid bookId is required" });

    const book = await Book.findById(bookId);
    if (!book) return res.status(404).json({ message: "Book not found" });
    if (book.availableCopies <= 0) return res.status(409).json({ message: "No copies of this book are currently available" });

    const duplicate = await BorrowRequest.exists({ user: req.user._id, book: book._id, status: { $in: ACTIVE } });
    if (duplicate) return res.status(409).json({ message: "You already have an open request or loan for this book" });

    // user comes from the verified token, title/author from the DB, never from the client.
    const borrowRequest = await BorrowRequest.create({
      book: book._id, user: req.user._id, bookTitle: book.title, bookAuthor: book.author,
    });
    res.status(201).json({ borrowRequest });
  } catch (error) { next(error); }
});

// GET /api/borrow-requests/mine  (the patron's own requests)
router.get("/mine", requireAuth, async (req, res, next) => {
  try {
    res.json({ borrowRequests: await BorrowRequest.find({ user: req.user._id }).sort({ requestedAt: -1 }) });
  } catch (error) { next(error); }
});

// GET /api/borrow-requests  (librarian: everything)
router.get("/", ...librarianOnly, async (_req, res, next) => {
  try {
    const borrowRequests = await BorrowRequest.find().populate("user", "username email").sort({ requestedAt: -1 });
    res.json({ borrowRequests });
  } catch (error) { next(error); }
});

// PATCH /api/borrow-requests/:id  { status, dueAt? }   (librarian only)
// Only `status` (and `dueAt` when approving) are read from the body. `fine` and `returnedAt`
// are ignored: the server computes them.
router.patch("/:id", ...librarianOnly, async (req, res, next) => {
  try {
    const { id } = req.params;
    const target = req.body?.status;
    if (!mongoose.isValidObjectId(id)) return res.status(400).json({ message: "Invalid borrow request id" });
    if (!Object.keys(TRANSITIONS).includes(target)) return res.status(400).json({ message: "status must be one of: pending, approved, late, returned" });

    const request = await BorrowRequest.findById(id);
    if (!request) return res.status(404).json({ message: "Borrow request not found" });
    if (!TRANSITIONS[request.status].includes(target)) {
      return res.status(409).json({ message: `Cannot change status from "${request.status}" to "${target}"` });
    }

    const now = new Date();
    let updated;

    if (target === "approved") {
      let dueAt = new Date(now.getTime() + LOAN_DAYS() * 86400000);
      if (req.body.dueAt !== undefined && req.body.dueAt !== "") {
        dueAt = new Date(req.body.dueAt);
        if (Number.isNaN(dueAt.getTime())) return res.status(400).json({ message: "dueAt is not a valid date" });
      }
      // Atomically claim a copy: only succeeds if one is still available.
      const claimed = await Book.findOneAndUpdate({ _id: request.book, availableCopies: { $gt: 0 } }, { $inc: { availableCopies: -1 } });
      if (!claimed) {
        const exists = await Book.exists({ _id: request.book });
        return res.status(exists ? 409 : 404).json({ message: exists ? "No copies available to lend right now" : "The requested book no longer exists" });
      }
      updated = await BorrowRequest.findOneAndUpdate({ _id: id, status: "pending" }, { status: "approved", dueAt }, { new: true });
      if (!updated) { // someone else changed it first: give the copy back
        await Book.updateOne({ _id: request.book }, { $inc: { availableCopies: 1 } });
        return res.status(409).json({ message: "This request was already updated by someone else" });
      }
    } else if (target === "late") {
      if (!request.dueAt || request.dueAt > now) return res.status(409).json({ message: "This loan is not past its due date yet" });
      updated = await BorrowRequest.findOneAndUpdate({ _id: id, status: "approved" }, { status: "late" }, { new: true });
    } else if (target === "returned") {
      // Fine is computed here from the stored due date and the server clock. Never from the client.
      const fine = calculateFine(request.dueAt, now);
      updated = await BorrowRequest.findOneAndUpdate(
        { _id: id, status: { $in: ["approved", "late"] } },
        { status: "returned", returnedAt: now, fine },
        { new: true }
      );
      if (updated) {
        // Return the copy, never exceeding totalCopies.
        await Book.updateOne({ _id: request.book, $expr: { $lt: ["$availableCopies", "$totalCopies"] } }, { $inc: { availableCopies: 1 } });
      }
    }

    if (!updated) return res.status(409).json({ message: "This request was already updated by someone else" });
    await updated.populate("user", "username email");
    res.json({ borrowRequest: updated });
  } catch (error) { next(error); }
});

module.exports = router;
module.exports.TRANSITIONS = TRANSITIONS;
